from ultralytics import YOLO
from PIL import Image as PILImage
import cv2
import torch
import numpy as np
from torchvision import transforms
from torchvision.models import efficientnet_b0, EfficientNet_B0_Weights
from transformers import Mask2FormerForUniversalSegmentation, Mask2FormerImageProcessor
from scipy.ndimage import gaussian_filter1d
import os

# === Configuration ===
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
YOLO_MODEL_PATH = 'finalChecks/best.pt'
MASK2FORMER_CKPT = 'finalChecks/mask2former_epoch_7.pt'
MASK2FORMER_MODEL = 'facebook/mask2former-swin-base-ade-semantic'
EFFNET_CKPT = 'finalChecks/best_model_2target.pt'

# === Load Models ===
def load_mask2former():
    model = Mask2FormerForUniversalSegmentation.from_pretrained(MASK2FORMER_MODEL, ignore_mismatched_sizes=True)
    processor = Mask2FormerImageProcessor.from_pretrained(MASK2FORMER_MODEL, reduce_labels=True)
    checkpoint = torch.load(MASK2FORMER_CKPT, map_location=DEVICE)
    model.load_state_dict(checkpoint['model_state_dict'])
    model.to(DEVICE).eval()
    return model, processor

def load_efficientnet():
    model = efficientnet_b0(weights=EfficientNet_B0_Weights.DEFAULT)
    model.classifier[1] = torch.nn.Sequential(
        torch.nn.Linear(model.classifier[1].in_features, 128),
        torch.nn.ReLU(),
        torch.nn.Dropout(0.6),
        torch.nn.Linear(128, 2)
    )
    model.load_state_dict(torch.load(EFFNET_CKPT, map_location=DEVICE))
    model.to(DEVICE).eval()
    return model

# === Detect and Crop Tongue ===
def detect_and_crop(image_path, save_path="./cropped_tongue.jpg"):
    model = YOLO(YOLO_MODEL_PATH)
    results = model(image_path)[0]
    img = cv2.imread(image_path)

    for box in results.boxes:
        if int(box.cls[0]) == 1 and float(box.conf[0]) > 0.5:
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            cropped = img[y1:y2, x1:x2]
            cv2.imwrite(save_path, cropped)
            return save_path
    return None

# === Compute Curvature ===
def compute_curvature(contour, smooth_sigma=5):
    if contour.shape[0] < 2:
        return np.array([])
    x = contour[:, 0, 0].astype(np.float32)
    y = contour[:, 0, 1].astype(np.float32)
    x_smooth = gaussian_filter1d(x, sigma=smooth_sigma)
    y_smooth = gaussian_filter1d(y, sigma=smooth_sigma)
    dx, dy = np.gradient(x_smooth), np.gradient(y_smooth)
    ddx, ddy = np.gradient(dx), np.gradient(dy)
    return (dx * ddy - dy * ddx) / ((dx**2 + dy**2)**1.5 + 1e-8)

def get_jaggedness_score(curvature_values):
    if curvature_values.size == 0:
        return 0.0
    abs_curv = np.abs(curvature_values)
    avg_curv = np.mean(abs_curv)
    high_ratio = np.sum(abs_curv > 0.05) / len(abs_curv)
    raw_score = (avg_curv * 50) + (high_ratio * 25)
    return round(min(max(raw_score, 0), 10), 2)

def compute_crack_score(image_path, window_size=32, stride=16, edge_threshold=50):
    image = cv2.imread(image_path)
    if image is None:
        return 0.0
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150)
    h, w = edges.shape
    crack_windows, total_windows = 0, 0
    for y in range(0, h - window_size + 1, stride):
        for x in range(0, w - window_size + 1, stride):
            window = edges[y:y + window_size, x:x + window_size]
            if np.sum(window > 0) >= edge_threshold:
                crack_windows += 1
            total_windows += 1
    return round(min((crack_windows / total_windows) * 20, 10), 2) if total_windows > 0 else 0.0

def compute_coated_tongue_score(image_path):
    image = cv2.imread(image_path)
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    white_mask = cv2.inRange(hsv, (0, 0, 180), (180, 60, 255))
    yellow_mask = cv2.inRange(hsv, (15, 60, 120), (40, 255, 255))
    coating_mask = cv2.bitwise_or(white_mask, yellow_mask)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    _, tongue_mask = cv2.threshold(gray, 10, 255, cv2.THRESH_BINARY)
    coated_pixels = cv2.countNonZero(cv2.bitwise_and(coating_mask, coating_mask, mask=tongue_mask))
    tongue_pixels = cv2.countNonZero(tongue_mask)
    return round(min((coated_pixels / tongue_pixels) * 10, 10), 2) if tongue_pixels > 0 else 0.0

# === Segment + Predict ===
def process_and_predict(image_path, mask2former_model, processor, effnet_model, output_path="output_tongue_color_masked.png"):
    image = PILImage.open(image_path).convert("RGB")
    image_np = np.array(image)
    inputs = processor(images=image, return_tensors="pt").to(DEVICE)

    with torch.no_grad():
        outputs = mask2former_model(**inputs)

    seg = processor.post_process_semantic_segmentation(outputs, target_sizes=[(image.height, image.width)])[0].cpu().numpy()
    mask = (seg == 1).astype(np.uint8)
    mask_3ch = np.stack([mask]*3, axis=-1)
    masked_output = np.where(mask_3ch == 1, image_np, 0)
    cv2.imwrite(output_path, cv2.cvtColor(masked_output, cv2.COLOR_RGB2BGR))

    # Preprocess for EfficientNet
    preprocess = transforms.Compose([
        transforms.ToPILImage(),
        transforms.Resize((240, 240)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])
    input_tensor = preprocess(masked_output).unsqueeze(0).to(DEVICE)

    with torch.no_grad():
        preds = effnet_model(input_tensor).cpu().squeeze().numpy()

    jagged_score = 0.0
    binary_mask = (mask * 255).astype(np.uint8)
    edges = cv2.Canny(binary_mask, 50, 150)
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if contours:
        contour = max(contours, key=cv2.contourArea)
        if len(contour) >= 2:
            curvature = compute_curvature(contour)
            jagged_score = get_jaggedness_score(curvature)

    crack_score = compute_crack_score(output_path)
    coated_score = compute_coated_tongue_score(output_path)

    return {
        "segmented_path": output_path,
        "jagged_score": jagged_score,
        "crack_score": crack_score,
        "coated_score": coated_score,
        "filiform_papillae": round(float(preds[0]), 2),
        "fungiform_redness": round(float(preds[1]), 2)
    }

# === Run Prediction ===
if __name__ == "__main__":
    image_path = '/media/jag/volD/hcl/finalChecks/Coated Tongue.png'
    cropped_path = "./cropped_tongue.jpg"
    final_masked_path = "./output_tongue_color_masked.png"

    cropped = detect_and_crop(image_path, cropped_path)
    if not cropped:
        print("❌ Tongue not detected.")
        exit()

    mask2former_model, processor = load_mask2former()
    effnet_model = load_efficientnet()

    result = process_and_predict(cropped, mask2former_model, processor, effnet_model, final_masked_path)

    print(f"✅ Cropped: {cropped_path}")
    print(f"✅ Masked: {result['segmented_path']}")
    print(f"✅ Jaggedness Score: {result['jagged_score']}/10")
    print(f"✅ Crack Score: {result['crack_score']}/10")
    print(f"✅ Coated Tongue Score: {result['coated_score']}/10")
    print(f"✅ Filiform Papillae: {result['filiform_papillae']}")
    print(f"✅ Fungiform Redness: {result['fungiform_redness']}")

    # Compute inline scores
    nutrition_score = (
        0.5 * result['fungiform_redness'] +
        0.3 * result['filiform_papillae'] +
        0.2 * (10 - result['coated_score'])
    )

    mantle_score = (
        0.6 * result['crack_score'] +
        0.4 * result['jagged_score']
    )

    print(f"✅ Nutrition Score: {nutrition_score:.2f}/10")
    print(f"✅ Mantle Score: {mantle_score:.2f}/10")




