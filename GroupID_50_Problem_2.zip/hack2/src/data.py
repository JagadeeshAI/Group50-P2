import os
import json
import torch
from PIL import Image
from torchvision import transforms
from torch.utils.data import Dataset, DataLoader, random_split
from transformers import Mask2FormerForUniversalSegmentation, Mask2FormerImageProcessor

# === Device Setup ===
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# === Load Mask2Former Model ===
def load_mask2former_model():
    model = Mask2FormerForUniversalSegmentation.from_pretrained(
        "facebook/mask2former-swin-base-ade-semantic", ignore_mismatched_sizes=True
    )
    processor = Mask2FormerImageProcessor.from_pretrained(
        "facebook/mask2former-swin-base-ade-semantic", reduce_labels=True
    )
    checkpoint = torch.load("finalChecks/mask2former_epoch_7.pt", map_location=DEVICE)
    model.load_state_dict(checkpoint['model_state_dict'])
    model.to(DEVICE).eval()
    return model, processor

mask2former_model, mask2former_processor = load_mask2former_model()

# === Data Transforms ===
train_transform = transforms.Compose([
    transforms.Resize((240, 240)),
    transforms.RandomHorizontalFlip(),
    transforms.RandomRotation(10),
    transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225])
])

val_transform = transforms.Compose([
    transforms.Resize((240, 240)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225])
])

# === Dataset Class ===
class ScoreDataset(Dataset):
    def __init__(self, json_path, transform=None):
        with open(json_path, 'r') as f:
            self.data = json.load(f)
        self.transform = transform
        self.resize = transforms.Resize((240, 240))

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        entry = self.data[idx]
        img_path = entry['file_path']
        image = Image.open(img_path).convert("RGB")
        image_resized = self.resize(image)

        # Get segmentation mask
        inputs = mask2former_processor(images=image_resized, return_tensors="pt").to(DEVICE)
        with torch.no_grad():
            outputs = mask2former_model(**inputs)

        seg = mask2former_processor.post_process_semantic_segmentation(
            outputs, target_sizes=[(240, 240)]
        )[0].cpu().numpy().astype("uint8")
        
        mask = (seg == 1).astype("float32")
        mask_tensor = torch.tensor(mask).unsqueeze(0).to(DEVICE)  # [1, H, W]

        # Prepare image tensor
        image_tensor = transforms.ToTensor()(image_resized).to(DEVICE)

        # Apply segmentation mask
        masked_tensor = image_tensor * mask_tensor

        # Apply final transforms (CPU-based)
        if self.transform:
            masked_tensor = self.transform(transforms.ToPILImage()(masked_tensor.cpu()))

        scores = entry["scores"]
        selected_scores = torch.tensor([
            scores["Filiform_Papillae"],
            scores["Fungiform_Redness"]
        ], dtype=torch.float32)

        return masked_tensor, selected_scores

# === Loader Function ===
def load_score_data(json_path="results/scores.json", batch_size=16):
    full_dataset = ScoreDataset(json_path, transform=None)
    train_size = int(0.8 * len(full_dataset))
    val_size = len(full_dataset) - train_size
    train_set, val_set = random_split(full_dataset, [train_size, val_size])
    train_set.dataset.transform = train_transform
    val_set.dataset.transform = val_transform

    train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_set, batch_size=batch_size)
    return train_loader, val_loader
